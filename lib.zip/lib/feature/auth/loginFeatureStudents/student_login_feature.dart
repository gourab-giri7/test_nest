import 'dart:developer';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:test_nest/feature/domain/student/data/models/student_data_model.dart';

class StudentLoginFeature {
  static final firestore = FirebaseFirestore.instance;

  static Future<String?> resolveTeacherDocumentId(String input) async {
    final value = input.trim();
    if (value.isEmpty) return null;
    final direct = await firestore.collection('user').doc(value).get();
    if (direct.exists) return direct.id;
    final users = await firestore.collection('user').get();
    for (final doc in users.docs) {
      final d = doc.data();
      final candidates = [doc.id, d['id'], d['teacher_id']].map((e) => e?.toString().trim().toLowerCase()).toList();
      if (candidates.contains(value.toLowerCase())) return doc.id;
    }
    return null;
  }

  static Future<int> studentlogin(
    String teacherIdInput,
    String studentIdInput,
    String passwordInput,
  ) async {
    try {
      final trimmedTeacherId = teacherIdInput.trim();
      final trimmedStudentId = studentIdInput.trim();
      final trimmedPassword = passwordInput.trim();

      String? resolvedTeacherDocId;

      // 1. Check if trimmedTeacherId is directly a document ID in collection('user')
      final directDoc = await firestore.collection("user").doc(trimmedTeacherId).get();
      if (directDoc.exists) {
        resolvedTeacherDocId = directDoc.id;
      } else {
        // 2. Search collection('user') by teacher_id or id field
        final usersSnapshot = await firestore.collection("user").get();
        for (final doc in usersSnapshot.docs) {
          final data = doc.data();
          final tid = (data["teacher_id"] ?? "").toString().trim();
          final id = (data["id"] ?? "").toString().trim();
          if (doc.id.toLowerCase() == trimmedTeacherId.toLowerCase() ||
              tid.toLowerCase() == trimmedTeacherId.toLowerCase() ||
              id.toLowerCase() == trimmedTeacherId.toLowerCase()) {
            resolvedTeacherDocId = doc.id;
            break;
          }
        }
      }

      if (resolvedTeacherDocId == null) {
        log("Teacher not found: $trimmedTeacherId");
        return 404;
      }

      // 3. Query user/{teacherDocumentId}/students
      final studentsSnapshot = await firestore
          .collection("user")
          .doc(resolvedTeacherDocId)
          .collection("students")
          .get();

      for (final doc in studentsSnapshot.docs) {
        final data = doc.data();
        final sid = (data["id"] ?? doc.id).toString().trim();
        final spass = (data["password"] ?? "").toString().trim();

        if (sid.toLowerCase() == trimmedStudentId.toLowerCase() &&
            spass == trimmedPassword) {
          studentData = StudentData.fromJson(data);
          // Ensure teacherId refers to the correct teacher document ID
          studentData!.teacherId = resolvedTeacherDocId;
          StudentData.updateStudentLocalData();
          return 200;
        }
      }
    } catch (e) {
      log("Student login error: $e", name: "login error");
      return 400;
    }

    return 404;
  }
}
