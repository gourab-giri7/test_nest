import 'dart:developer';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:test_nest/feature/domain/teacher/data/models/teacher_data_model.dart';

class TeacherLoginFeature {
  static final firestore = FirebaseFirestore.instance;

  static Future<int> teacherlogin(String id, String password) async {
    try {
      final trimmedInputId = id.trim();
      final trimmedPassword = password.trim();

      final usersSnapshot = await firestore.collection("user").get();
      for (final doc in usersSnapshot.docs) {
        final data = doc.data();
        final docId = doc.id.trim();
        final dataId = (data["id"] ?? "").toString().trim();
        final dataTeacherId = (data["teacher_id"] ?? "").toString().trim();
        final dataPassword = (data["password"] ?? "").toString().trim();

        final matchesId = docId.toLowerCase() == trimmedInputId.toLowerCase() ||
            dataId.toLowerCase() == trimmedInputId.toLowerCase() ||
            dataTeacherId.toLowerCase() == trimmedInputId.toLowerCase();

        if (matchesId && dataPassword == trimmedPassword) {
          teacherData = TeacherData.fromJson(data, docId: doc.id);
          TeacherData.updateTeacherLocalData();
          return 200;
        }
      }
    } catch (e) {
      log("Login error: $e", name: "login error");
      return 400;
    }

    return 404;
  }
}
