import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:test_nest/core/context/active_tenant_context.dart';
import 'package:test_nest/core/services/batch_assignment_service.dart';
import 'package:test_nest/core/services/organization_service.dart';
import 'package:test_nest/core/utils/theme/theme.dart';
import 'package:test_nest/feature/domain/common/presentation/screen/login/controller/login_controller.dart';
import 'package:test_nest/core/utils/custom_snackbar.dart';
import 'package:test_nest/feature/domain/organization/presentation/controllers/institute_admin_dashboard_controller.dart';
import 'package:test_nest/feature/domain/organization/presentation/screens/batch_details_screen.dart';
import 'package:test_nest/model/batch_model.dart';
import 'package:test_nest/model/join_request_model.dart';
import 'package:test_nest/model/organization_model.dart';
import 'package:test_nest/routes/app_routes.dart';

class InstituteAdminDashboardScreen extends StatelessWidget {
  const InstituteAdminDashboardScreen({super.key});

  static const Color _muted = Color(0xFF64748B);
  static const Color _surface = Colors.white;

  @override
  Widget build(BuildContext context) {
    final tenantCtx = context.watch<ActiveTenantContext>();

    return ChangeNotifierProvider<InstituteAdminDashboardController>(
      create: (_) =>
          InstituteAdminDashboardController(tenantContext: tenantCtx),
      child: Consumer<InstituteAdminDashboardController>(
        builder: (context, controller, _) {
          return Scaffold(
            backgroundColor: AppColors.background,
            body: SafeArea(
              child: IndexedStack(
                index: controller.currentTabIndex,
                children: [
                  _OwnerHomeTab(controller: controller, tenantCtx: tenantCtx),
                  _OwnerTeachersTab(
                    controller: controller,
                    tenantCtx: tenantCtx,
                  ),
                  _OwnerStudentsTab(
                    controller: controller,
                    tenantCtx: tenantCtx,
                  ),
                  _OwnerBatchesTab(
                    controller: controller,
                    tenantCtx: tenantCtx,
                  ),
                  _OwnerMoreTab(controller: controller, tenantCtx: tenantCtx),
                ],
              ),
            ),
            bottomNavigationBar: BottomNavigationBar(
              currentIndex: controller.currentTabIndex,
              onTap: controller.switchTab,
              type: BottomNavigationBarType.fixed,
              backgroundColor: _surface,
              selectedItemColor: AppColors.primary,
              unselectedItemColor: _muted,
              selectedLabelStyle: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 12,
              ),
              unselectedLabelStyle: const TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 12,
              ),
              items: [
                const BottomNavigationBarItem(
                  icon: Icon(Icons.dashboard_outlined),
                  activeIcon: Icon(Icons.dashboard),
                  label: 'Home',
                ),
                const BottomNavigationBarItem(
                  icon: Icon(Icons.people_outline),
                  activeIcon: Icon(Icons.people),
                  label: 'Teachers',
                ),
                BottomNavigationBarItem(
                  icon: controller.pendingJoinRequests > 0
                      ? Badge(
                          label: Text('${controller.pendingJoinRequests}'),
                          child: const Icon(Icons.school_outlined),
                        )
                      : const Icon(Icons.school_outlined),
                  activeIcon: controller.pendingJoinRequests > 0
                      ? Badge(
                          label: Text('${controller.pendingJoinRequests}'),
                          child: const Icon(Icons.school),
                        )
                      : const Icon(Icons.school),
                  label: 'Students',
                ),
                const BottomNavigationBarItem(
                  icon: Icon(Icons.class_outlined),
                  activeIcon: Icon(Icons.class_),
                  label: 'Batches',
                ),
                const BottomNavigationBarItem(
                  icon: Icon(Icons.grid_view_outlined),
                  activeIcon: Icon(Icons.grid_view),
                  label: 'More',
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// =============================================================================
// TAB 1: OWNER HOME (DASHBOARD)
// =============================================================================

class _OwnerHomeTab extends StatelessWidget {
  final InstituteAdminDashboardController controller;
  final ActiveTenantContext tenantCtx;

  const _OwnerHomeTab({required this.controller, required this.tenantCtx});

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async => controller.refresh(),
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(
          parent: BouncingScrollPhysics(),
        ),
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
        children: [
          _buildTopHeader(context),
          const SizedBox(height: 16),
          _buildSummaryStatsGrid(),
          const SizedBox(height: 20),
          _buildRecentJoinRequestsSection(context),
          const SizedBox(height: 20),
          _buildBatchOverviewSection(context),
          const SizedBox(height: 20),
          _buildRecentActivitySection(context),
        ],
      ),
    );
  }

  Widget _buildTopHeader(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE2E8F0)),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0F172A).withValues(alpha: 0.03),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF2563EB), Color(0xFF4F46E5)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.account_balance,
              color: Colors.white,
              size: 24,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  tenantCtx.activeOrgName.isNotEmpty
                      ? tenantCtx.activeOrgName
                      : 'Coaching Institute',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF0F172A),
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFFEFF6FF),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: const Text(
                        'INSTITUTE OWNER',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF2563EB),
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    const Text(
                      '• Active Mode',
                      style: TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                    ),
                  ],
                ),
              ],
            ),
          ),
          IconButton(
            tooltip: 'Switch Workspace',
            icon: const Icon(Icons.swap_horiz, color: Color(0xFF2563EB)),
            onPressed: () => Get.toNamed(AppRoutes.organizationSwitcher),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryStatsGrid() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final crossAxisCount = constraints.maxWidth > 500 ? 3 : 2;
        final aspectRatio = constraints.maxWidth < 360 ? 1.35 : 1.5;
        return GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: crossAxisCount,
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: aspectRatio,
          children: [
            _buildStatCard(
              title: 'Total Students',
              value: '${controller.totalStudents}',
              icon: Icons.school_outlined,
              iconColor: const Color(0xFF2563EB),
              bgColor: const Color(0xFFEFF6FF),
            ),
            _buildStatCard(
              title: 'Total Teachers',
              value: '${controller.totalTeachers}',
              icon: Icons.people_outline,
              iconColor: const Color(0xFF7C3AED),
              bgColor: const Color(0xFFF5F3FF),
            ),
            _buildStatCard(
              title: 'Total Batches',
              value: '${controller.totalBatches}',
              icon: Icons.class_outlined,
              iconColor: const Color(0xFF0D9488),
              bgColor: const Color(0xFFCCFBF1),
            ),
            _buildStatCard(
              title: 'Active Exams',
              value: '${controller.activeExams}',
              icon: Icons.assignment_outlined,
              iconColor: const Color(0xFFD97706),
              bgColor: const Color(0xFFFEF3C7),
            ),
            _buildStatCard(
              title: 'Pending Requests',
              value: '${controller.pendingJoinRequests}',
              icon: Icons.person_add_outlined,
              iconColor: controller.pendingJoinRequests > 0
                  ? Colors.red
                  : const Color(0xFF10B981),
              bgColor: controller.pendingJoinRequests > 0
                  ? const Color(0xFFFEE2E2)
                  : const Color(0xFFD1FAE5),
            ),
            _buildStatCard(
              title: 'Today Attendance',
              value: controller.todayAttendanceTotal > 0
                  ? '${controller.todayAttendancePresent}/${controller.todayAttendanceTotal}'
                  : '--',
              subtitle: controller.todayAttendanceTotal > 0
                  ? 'marked today'
                  : 'not marked',
              icon: Icons.fact_check_outlined,
              iconColor: const Color(0xFF0284C7),
              bgColor: const Color(0xFFE0F2FE),
            ),
          ],
        );
      },
    );
  }

  Widget _buildStatCard({
    required String title,
    required String value,
    String? subtitle,
    required IconData icon,
    required Color iconColor,
    required Color bgColor,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF64748B),
                  ),
                ),
              ),
              const SizedBox(width: 4),
              Container(
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  color: bgColor,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(icon, size: 16, color: iconColor),
              ),
            ],
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: [
              Text(
                value,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF0F172A),
                ),
              ),
              if (subtitle != null) ...[
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 10,
                      color: Color(0xFF64748B),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildRecentJoinRequestsSection(BuildContext context) {
    final requests = controller.recentJoinRequests;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const Text(
                    'Pending Join Requests',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF0F172A),
                    ),
                  ),
                  if (requests.isNotEmpty) ...[
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.red.shade100,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        '${requests.length}',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          color: Colors.red.shade800,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
              TextButton(
                onPressed: () =>
                    controller.switchTab(2), // Switch to Students tab
                child: const Text('Review All'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (requests.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 12),
              child: Center(
                child: Text(
                  'No pending join requests. All caught up!',
                  style: TextStyle(fontSize: 13, color: Color(0xFF64748B)),
                ),
              ),
            )
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: requests.take(3).length,
              separatorBuilder: (_, __) => const Divider(height: 12),
              itemBuilder: (context, index) {
                final req = requests[index];
                return Row(
                  children: [
                    CircleAvatar(
                      radius: 16,
                      backgroundColor: const Color(0xFFEFF6FF),
                      child: Text(
                        req.studentName.isNotEmpty
                            ? req.studentName[0].toUpperCase()
                            : 'S',
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF2563EB),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            req.studentName,
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF0F172A),
                            ),
                          ),
                          Text(
                            req.studentEmail,
                            style: const TextStyle(
                              fontSize: 11,
                              color: Color(0xFF64748B),
                            ),
                          ),
                        ],
                      ),
                    ),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF2563EB),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 4,
                        ),
                        textStyle: const TextStyle(fontSize: 11),
                      ),
                      onPressed: () => controller.switchTab(2),
                      child: const Text('Review'),
                    ),
                  ],
                );
              },
            ),
        ],
      ),
    );
  }

  Widget _buildBatchOverviewSection(BuildContext context) {
    final batches = controller.batches;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Active Batches Overview',
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF0F172A),
                ),
              ),
              TextButton(
                onPressed: () =>
                    controller.switchTab(3), // Switch to Batches tab
                child: const Text('Manage Batches'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (batches.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 12),
              child: Center(
                child: Text(
                  'No batches created yet. Add your first batch in Batches tab.',
                  style: TextStyle(fontSize: 13, color: Color(0xFF64748B)),
                ),
              ),
            )
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: batches.take(4).length,
              separatorBuilder: (_, __) => const Divider(height: 12),
              itemBuilder: (context, index) {
                final b = batches[index];
                return InkWell(
                  onTap: () => Get.to(
                    () => BatchDetailsScreen(orgId: controller.orgId, batch: b),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF1F5F9),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(
                            Icons.class_outlined,
                            size: 18,
                            color: Color(0xFF2563EB),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                b.name,
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: Color(0xFF0F172A),
                                ),
                              ),
                              Text(
                                '${b.studentCount} Students • ${b.assignedTeacherIds.length} Teachers',
                                style: const TextStyle(
                                  fontSize: 11,
                                  color: Color(0xFF64748B),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Icon(
                          Icons.arrow_forward_ios,
                          size: 12,
                          color: Color(0xFF94A3B8),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  Widget _buildRecentActivitySection(BuildContext context) {
    final exams = controller.recentExams;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Recent Institute Activity',
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF0F172A),
                ),
              ),
              TextButton(
                onPressed: () => Get.toNamed(AppRoutes.teacherExams),
                child: const Text('All Exams'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (exams.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 12),
              child: Center(
                child: Text(
                  'No recent exam activity recorded.',
                  style: TextStyle(fontSize: 13, color: Color(0xFF64748B)),
                ),
              ),
            )
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: exams.take(3).length,
              separatorBuilder: (_, __) => const Divider(height: 12),
              itemBuilder: (context, index) {
                final e = exams[index];
                return Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFEF3C7),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(
                        Icons.assignment_outlined,
                        size: 16,
                        color: Color(0xFFD97706),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            e.examName,
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF0F172A),
                            ),
                          ),
                          Text(
                            'Status: ${e.status} • Batch: ${e.batch}',
                            style: const TextStyle(
                              fontSize: 11,
                              color: Color(0xFF64748B),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Text(
                      e.examDate,
                      style: const TextStyle(
                        fontSize: 11,
                        color: Color(0xFF64748B),
                      ),
                    ),
                  ],
                );
              },
            ),
        ],
      ),
    );
  }
}

// =============================================================================
// TAB 2: OWNER TEACHERS MANAGEMENT
// =============================================================================

class _OwnerTeachersTab extends StatefulWidget {
  final InstituteAdminDashboardController controller;
  final ActiveTenantContext tenantCtx;

  const _OwnerTeachersTab({required this.controller, required this.tenantCtx});

  @override
  State<_OwnerTeachersTab> createState() => _OwnerTeachersTabState();
}

class _OwnerTeachersTabState extends State<_OwnerTeachersTab> {
  final OrganizationService _orgService = OrganizationService();
  final BatchAssignmentService _assignmentService = BatchAssignmentService();
  final TextEditingController _searchCtrl = TextEditingController();
  String _searchQuery = '';

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildTeachersHeader(),
        _buildSearchBar(),
        Expanded(
          child: StreamBuilder<List<OrganizationMemberModel>>(
            stream: _orgService.streamOrganizationMembers(
              widget.controller.orgId,
            ),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              final allMembers = snapshot.data ?? [];
              final teachers = allMembers
                  .where((m) => m.isTeacher || m.isAdmin)
                  .where((m) {
                    if (_searchQuery.isEmpty) return true;
                    final q = _searchQuery.toLowerCase();
                    return m.name.toLowerCase().contains(q) ||
                        m.email.toLowerCase().contains(q);
                  })
                  .toList();

              if (teachers.isEmpty) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.people_outline,
                          size: 48,
                          color: Colors.grey,
                        ),
                        const SizedBox(height: 10),
                        Text(
                          _searchQuery.isEmpty
                              ? 'No teachers added yet.'
                              : 'No teachers match "$_searchQuery".',
                          style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 12),
                        ElevatedButton.icon(
                          icon: const Icon(Icons.person_add_alt_1, size: 16),
                          label: const Text('Invite Educator'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primary,
                            foregroundColor: Colors.white,
                          ),
                          onPressed: () =>
                              Get.toNamed(AppRoutes.manageInvitations),
                        ),
                      ],
                    ),
                  ),
                );
              }

              return ListView.separated(
                padding: const EdgeInsets.all(16),
                itemCount: teachers.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, index) {
                  final teacher = teachers[index];
                  return _buildTeacherCard(teacher);
                },
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildTeachersHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      color: Colors.white,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            'Faculty Directory',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Color(0xFF0F172A),
            ),
          ),
          Row(
            children: [
              OutlinedButton.icon(
                icon: const Icon(Icons.mark_email_read_outlined, size: 14),
                label: const Text('Invitations'),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 6,
                  ),
                  textStyle: const TextStyle(fontSize: 12),
                ),
                onPressed: () => Get.toNamed(AppRoutes.manageInvitations),
              ),
              const SizedBox(width: 8),
              ElevatedButton.icon(
                icon: const Icon(Icons.person_add_alt_1, size: 14),
                label: const Text('Invite'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 6,
                  ),
                  textStyle: const TextStyle(fontSize: 12),
                ),
                onPressed: () => Get.toNamed(AppRoutes.manageInvitations),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: TextField(
        controller: _searchCtrl,
        onChanged: (v) => setState(() => _searchQuery = v.trim()),
        decoration: InputDecoration(
          hintText: 'Search faculty by name or email...',
          prefixIcon: const Icon(Icons.search, size: 20),
          suffixIcon: _searchQuery.isNotEmpty
              ? IconButton(
                  icon: const Icon(Icons.clear, size: 18),
                  onPressed: () {
                    _searchCtrl.clear();
                    setState(() => _searchQuery = '');
                  },
                )
              : null,
          filled: true,
          fillColor: const Color(0xFFF1F5F9),
          contentPadding: const EdgeInsets.symmetric(vertical: 0),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }

  Widget _buildTeacherCard(OrganizationMemberModel teacher) {
    final isSuspended = teacher.status.toLowerCase() == 'suspended';
    final batches = widget.controller.batches;
    final assignedBatchObjects = batches
        .where((b) => teacher.assignedBatchIds.contains(b.id))
        .toList();
    int studentCountAcrossBatches = 0;
    for (final b in assignedBatchObjects) {
      studentCountAcrossBatches += b.studentCount;
    }

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 20,
                backgroundColor: teacher.isAdmin
                    ? const Color(0xFFF5F3FF)
                    : const Color(0xFFEFF6FF),
                foregroundColor: teacher.isAdmin
                    ? const Color(0xFF7C3AED)
                    : const Color(0xFF2563EB),
                child: Text(
                  teacher.name.isNotEmpty ? teacher.name[0].toUpperCase() : 'T',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      teacher.name,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF0F172A),
                      ),
                    ),
                    Text(
                      teacher.email,
                      style: const TextStyle(
                        fontSize: 12,
                        color: Color(0xFF64748B),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: isSuspended
                      ? Colors.red.shade100
                      : const Color(0xFFDCFCE7),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  isSuspended ? 'Suspended' : teacher.role.toUpperCase(),
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: isSuspended
                        ? Colors.red.shade800
                        : const Color(0xFF166534),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              const Icon(
                Icons.calendar_today,
                size: 13,
                color: Color(0xFF64748B),
              ),
              const SizedBox(width: 4),
              Text(
                'Joined ${DateFormat('dd MMM yyyy').format(teacher.joinedAt)}',
                style: const TextStyle(fontSize: 12, color: Color(0xFF64748B)),
              ),
              const SizedBox(width: 12),
              const Icon(
                Icons.people_outline,
                size: 14,
                color: Color(0xFF64748B),
              ),
              const SizedBox(width: 4),
              Text(
                '$studentCountAcrossBatches Students',
                style: const TextStyle(fontSize: 12, color: Color(0xFF64748B)),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (assignedBatchObjects.isNotEmpty) ...[
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: assignedBatchObjects.map((b) {
                return Chip(
                  label: Text(b.name, style: const TextStyle(fontSize: 11)),
                  backgroundColor: const Color(0xFFF1F5F9),
                  padding: const EdgeInsets.all(0),
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                );
              }).toList(),
            ),
            const SizedBox(height: 8),
          ],
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton.icon(
                icon: const Icon(Icons.assignment_ind_outlined, size: 16),
                label: const Text('Manage Batches'),
                style: TextButton.styleFrom(
                  textStyle: const TextStyle(fontSize: 12),
                ),
                onPressed: () => _showManageTeacherBatches(teacher),
              ),
              if (!teacher.isAdmin) ...[
                const SizedBox(width: 4),
                TextButton(
                  style: TextButton.styleFrom(
                    foregroundColor: isSuspended
                        ? Colors.green
                        : Colors.orange.shade800,
                    textStyle: const TextStyle(fontSize: 12),
                  ),
                  onPressed: () => _toggleTeacherStatus(teacher),
                  child: Text(isSuspended ? 'Reactivate' : 'Suspend'),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }

  void _showManageTeacherBatches(OrganizationMemberModel teacher) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            final allBatches = widget.controller.batches;
            return SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Manage Batches: ${teacher.name}',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF0F172A),
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Assign or unassign teacher to institute batches',
                      style: TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                    ),
                    const SizedBox(height: 12),
                    if (allBatches.isEmpty)
                      const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text('No batches available.'),
                      )
                    else
                      Flexible(
                        child: ListView.separated(
                          shrinkWrap: true,
                          itemCount: allBatches.length,
                          separatorBuilder: (_, __) => const Divider(height: 1),
                          itemBuilder: (context, index) {
                            final b = allBatches[index];
                            final isAssigned = teacher.assignedBatchIds
                                .contains(b.id);

                            return CheckboxListTile(
                              title: Text(b.name),
                              subtitle: Text(
                                '${b.studentCount} students • ${b.subject ?? ""}',
                              ),
                              value: isAssigned,
                              onChanged: (val) async {
                                if (val == true) {
                                  await _assignmentService.assignTeacherToBatch(
                                    orgId: widget.controller.orgId,
                                    batchId: b.id,
                                    teacherUid: teacher.uid,
                                  );
                                  teacher.assignedBatchIds.add(b.id);
                                } else {
                                  await _assignmentService
                                      .removeTeacherFromBatch(
                                        orgId: widget.controller.orgId,
                                        batchId: b.id,
                                        teacherUid: teacher.uid,
                                      );
                                  teacher.assignedBatchIds.remove(b.id);
                                }
                                setSheetState(() {});
                                setState(() {});
                              },
                            );
                          },
                        ),
                      ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _toggleTeacherStatus(OrganizationMemberModel teacher) {
    final isSuspended = teacher.status.toLowerCase() == 'suspended';
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(isSuspended ? 'Reactivate Teacher?' : 'Suspend Teacher?'),
        content: Text(
          isSuspended
              ? 'Reactivate ${teacher.name}\'s faculty account?'
              : 'Suspend ${teacher.name}\'s access to the institute? '
                    'Student records, exams, and attendance history will remain untouched.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: isSuspended ? Colors.green : Colors.red,
            ),
            onPressed: () async {
              Navigator.pop(context);
              try {
                if (isSuspended) {
                  await _orgService.reactivateMember(
                    orgId: widget.controller.orgId,
                    memberUid: teacher.uid,
                  );
                } else {
                  await _orgService.suspendMember(
                    orgId: widget.controller.orgId,
                    memberUid: teacher.uid,
                  );
                }
                CustomSnackbar.showSuccess(
                  context: context,
                  title: isSuspended ? 'Reactivated' : 'Suspended',
                  message: '${teacher.name} status updated.',
                );
              } catch (e) {
                CustomSnackbar.showError(
                  context: context,
                  title: 'Error',
                  message: 'Action failed: $e',
                );
              }
            },
            child: Text(
              isSuspended ? 'Reactivate' : 'Suspend',
              style: const TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}

// =============================================================================
// TAB 3: OWNER STUDENTS DIRECTORY & JOIN REQUESTS
// =============================================================================

class _OwnerStudentsTab extends StatefulWidget {
  final InstituteAdminDashboardController controller;
  final ActiveTenantContext tenantCtx;

  const _OwnerStudentsTab({required this.controller, required this.tenantCtx});

  @override
  State<_OwnerStudentsTab> createState() => _OwnerStudentsTabState();
}

class _OwnerStudentsTabState extends State<_OwnerStudentsTab>
    with SingleTickerProviderStateMixin {
  final OrganizationService _orgService = OrganizationService();
  late TabController _subTabController;
  final TextEditingController _searchCtrl = TextEditingController();

  String _searchQuery = '';
  String? _selectedBatchFilter;

  @override
  void initState() {
    super.initState();
    _subTabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _subTabController.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          color: Colors.white,
          child: TabBar(
            controller: _subTabController,
            labelColor: AppColors.primary,
            unselectedLabelColor: const Color(0xFF64748B),
            indicatorColor: AppColors.primary,
            tabs: [
              const Tab(text: 'All Students'),
              Tab(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('Join Requests'),
                    if (widget.controller.pendingJoinRequests > 0) ...[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          '${widget.controller.pendingJoinRequests}',
                          style: const TextStyle(
                            fontSize: 10,
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: TabBarView(
            controller: _subTabController,
            children: [_buildAllStudentsSubTab(), _buildJoinRequestsSubTab()],
          ),
        ),
      ],
    );
  }

  // ── Sub-tab 1: All Institute Students ─────────────────────────────────────

  Widget _buildAllStudentsSubTab() {
    return Column(
      children: [
        _buildStudentFilters(),
        Expanded(
          child: StreamBuilder<List<OrganizationMemberModel>>(
            stream: _orgService.streamInstituteStudents(
              widget.controller.orgId,
            ),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              final allStudents = snapshot.data ?? [];
              final filtered = allStudents.where((s) {
                if (_selectedBatchFilter != null &&
                    _selectedBatchFilter!.isNotEmpty) {
                  if (!s.assignedBatchIds.contains(_selectedBatchFilter)) {
                    return false;
                  }
                }
                if (_searchQuery.isEmpty) return true;
                final q = _searchQuery.toLowerCase();
                return s.name.toLowerCase().contains(q) ||
                    s.email.toLowerCase().contains(q);
              }).toList();

              if (filtered.isEmpty) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.school_outlined,
                          size: 48,
                          color: Colors.grey,
                        ),
                        const SizedBox(height: 10),
                        Text(
                          _searchQuery.isEmpty
                              ? 'No students found in institute.'
                              : 'No students match your query.',
                          style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 6),
                        const Text(
                          'Students join via joining codes and are approved by you.',
                          style: TextStyle(
                            fontSize: 12,
                            color: Color(0xFF64748B),
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                );
              }

              return ListView.separated(
                padding: const EdgeInsets.all(16),
                itemCount: filtered.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (context, index) {
                  final student = filtered[index];
                  return _buildStudentCard(student);
                },
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildStudentFilters() {
    final batches = widget.controller.batches;

    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Column(
        children: [
          TextField(
            controller: _searchCtrl,
            onChanged: (v) => setState(() => _searchQuery = v.trim()),
            decoration: InputDecoration(
              hintText: 'Search by student name or email...',
              prefixIcon: const Icon(Icons.search, size: 20),
              filled: true,
              fillColor: const Color(0xFFF1F5F9),
              contentPadding: const EdgeInsets.symmetric(vertical: 0),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          if (batches.isNotEmpty) ...[
            const SizedBox(height: 8),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  ChoiceChip(
                    label: const Text('All Batches'),
                    selected: _selectedBatchFilter == null,
                    onSelected: (sel) {
                      if (sel) setState(() => _selectedBatchFilter = null);
                    },
                  ),
                  const SizedBox(width: 6),
                  ...batches.map((b) {
                    final isSel = _selectedBatchFilter == b.id;
                    return Padding(
                      padding: const EdgeInsets.only(right: 6),
                      child: ChoiceChip(
                        label: Text(b.name),
                        selected: isSel,
                        onSelected: (sel) {
                          setState(() {
                            _selectedBatchFilter = sel ? b.id : null;
                          });
                        },
                      ),
                    );
                  }),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildStudentCard(OrganizationMemberModel student) {
    final batches = widget.controller.batches;
    final assignedBatchObjects = batches
        .where((b) => student.assignedBatchIds.contains(b.id))
        .toList();

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 18,
                backgroundColor: const Color(0xFFF0FDF4),
                foregroundColor: const Color(0xFF16A34A),
                child: Text(
                  student.name.isNotEmpty ? student.name[0].toUpperCase() : 'S',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      student.name,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF0F172A),
                      ),
                    ),
                    Text(
                      student.email,
                      style: const TextStyle(
                        fontSize: 12,
                        color: Color(0xFF64748B),
                      ),
                    ),
                  ],
                ),
              ),
              PopupMenuButton<String>(
                icon: const Icon(
                  Icons.more_vert,
                  size: 20,
                  color: Color(0xFF64748B),
                ),
                onSelected: (action) {
                  if (action == 'enroll') {
                    _showEnrollBatchDialog(student);
                  } else if (action == 'transfer') {
                    _showTransferStudentDialog(student);
                  } else if (action == 'remove') {
                    _showRemoveFromBatchDialog(student);
                  }
                },
                itemBuilder: (context) => [
                  const PopupMenuItem(
                    value: 'enroll',
                    child: Row(
                      children: [
                        Icon(Icons.add_task, size: 18),
                        SizedBox(width: 8),
                        Text('Enroll in Batch'),
                      ],
                    ),
                  ),
                  if (student.assignedBatchIds.isNotEmpty) ...[
                    const PopupMenuItem(
                      value: 'transfer',
                      child: Row(
                        children: [
                          Icon(Icons.swap_horiz, size: 18),
                          SizedBox(width: 8),
                          Text('Transfer Batch'),
                        ],
                      ),
                    ),
                    const PopupMenuItem(
                      value: 'remove',
                      child: Row(
                        children: [
                          Icon(
                            Icons.remove_circle_outline,
                            size: 18,
                            color: Colors.red,
                          ),
                          SizedBox(width: 8),
                          Text(
                            'Remove from Batch',
                            style: TextStyle(color: Colors.red),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (assignedBatchObjects.isNotEmpty) ...[
            Wrap(
              spacing: 6,
              runSpacing: 4,
              children: assignedBatchObjects.map((b) {
                return Chip(
                  label: Text(b.name, style: const TextStyle(fontSize: 11)),
                  backgroundColor: const Color(0xFFEFF6FF),
                  padding: const EdgeInsets.all(0),
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                );
              }).toList(),
            ),
          ] else ...[
            const Text(
              'No batches assigned',
              style: TextStyle(fontSize: 11, color: Colors.orange),
            ),
          ],
        ],
      ),
    );
  }

  void _showEnrollBatchDialog(OrganizationMemberModel student) {
    final availableBatches = widget.controller.batches
        .where((b) => !student.assignedBatchIds.contains(b.id) && !b.isArchived)
        .toList();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Enroll ${student.name}'),
        content: availableBatches.isEmpty
            ? const Text('Student is already enrolled in all active batches.')
            : SizedBox(
                width: double.maxFinite,
                child: ListView.separated(
                  shrinkWrap: true,
                  itemCount: availableBatches.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, index) {
                    final b = availableBatches[index];
                    return ListTile(
                      title: Text(b.name),
                      subtitle: Text(b.subject ?? ''),
                      trailing: const Icon(
                        Icons.add_circle_outline,
                        color: AppColors.primary,
                      ),
                      onTap: () async {
                        Navigator.pop(context);
                        try {
                          await _orgService.enrollStudentInBatch(
                            orgId: widget.controller.orgId,
                            batchId: b.id,
                            batchName: b.name,
                            studentUid: student.uid,
                            studentName: student.name,
                            studentEmail: student.email,
                          );
                          CustomSnackbar.showSuccess(
                            context: context,
                            title: 'Enrolled',
                            message: '${student.name} enrolled in ${b.name}.',
                          );
                        } catch (e) {
                          CustomSnackbar.showError(
                            context: context,
                            title: 'Error',
                            message: 'Enrollment failed: $e',
                          );
                        }
                      },
                    );
                  },
                ),
              ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }

  void _showTransferStudentDialog(OrganizationMemberModel student) {
    final currentBatches = widget.controller.batches
        .where((b) => student.assignedBatchIds.contains(b.id))
        .toList();
    final otherBatches = widget.controller.batches
        .where((b) => !student.assignedBatchIds.contains(b.id) && !b.isArchived)
        .toList();

    if (currentBatches.isEmpty || otherBatches.isEmpty) {
      CustomSnackbar.showInfo(
        context: context,
        title: 'Transfer Not Possible',
        message: 'No alternative batches available to transfer to.',
      );
      return;
    }

    String fromBatchId = currentBatches.first.id;
    String toBatchId = otherBatches.first.id;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text('Transfer ${student.name}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('From Batch:'),
              DropdownButton<String>(
                isExpanded: true,
                value: fromBatchId,
                items: currentBatches
                    .map(
                      (b) => DropdownMenuItem(value: b.id, child: Text(b.name)),
                    )
                    .toList(),
                onChanged: (v) {
                  if (v != null) setDialogState(() => fromBatchId = v);
                },
              ),
              const SizedBox(height: 12),
              const Text('To Batch:'),
              DropdownButton<String>(
                isExpanded: true,
                value: toBatchId,
                items: otherBatches
                    .map(
                      (b) => DropdownMenuItem(value: b.id, child: Text(b.name)),
                    )
                    .toList(),
                onChanged: (v) {
                  if (v != null) setDialogState(() => toBatchId = v);
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
              ),
              onPressed: () async {
                Navigator.pop(context);
                final targetBatch = otherBatches.firstWhere(
                  (b) => b.id == toBatchId,
                );
                try {
                  await _orgService.transferStudentBatch(
                    orgId: widget.controller.orgId,
                    fromBatchId: fromBatchId,
                    toBatchId: toBatchId,
                    toBatchName: targetBatch.name,
                    studentUid: student.uid,
                    studentName: student.name,
                    studentEmail: student.email,
                  );
                  CustomSnackbar.showSuccess(
                    context: context,
                    title: 'Transferred',
                    message:
                        '${student.name} transferred to ${targetBatch.name}.',
                  );
                } catch (e) {
                  CustomSnackbar.showError(
                    context: context,
                    title: 'Error',
                    message: 'Transfer failed: $e',
                  );
                }
              },
              child: const Text(
                'Transfer',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showRemoveFromBatchDialog(OrganizationMemberModel student) {
    final currentBatches = widget.controller.batches
        .where((b) => student.assignedBatchIds.contains(b.id))
        .toList();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Remove from Batch: ${student.name}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Select the batch to remove the student from. '
              'The student will remain an organization member.',
            ),
            const SizedBox(height: 12),
            ...currentBatches.map(
              (b) => ListTile(
                title: Text(b.name),
                trailing: const Icon(Icons.remove_circle, color: Colors.red),
                onTap: () async {
                  Navigator.pop(context);
                  try {
                    await _orgService.removeStudentFromBatch(
                      orgId: widget.controller.orgId,
                      batchId: b.id,
                      studentUid: student.uid,
                    );
                    CustomSnackbar.showSuccess(
                      context: context,
                      title: 'Removed from Batch',
                      message: '${student.name} removed from ${b.name}.',
                    );
                  } catch (e) {
                    CustomSnackbar.showError(
                      context: context,
                      title: 'Error',
                      message: 'Action failed: $e',
                    );
                  }
                },
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }

  // ── Sub-tab 2: Pending Join Requests (Section 7) ──────────────────────────

  Widget _buildJoinRequestsSubTab() {
    return StreamBuilder<List<JoinRequestModel>>(
      stream: _orgService.streamOrganizationJoinRequests(
        widget.controller.orgId,
        status: 'pending',
      ),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        final requests = snapshot.data ?? [];
        if (requests.isEmpty) {
          return const Center(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.mark_email_read_outlined,
                    size: 48,
                    color: Colors.grey,
                  ),
                  SizedBox(height: 10),
                  Text(
                    'No pending requests.',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                  ),
                  SizedBox(height: 6),
                  Text(
                    'Student admission requests to your institute will appear here.',
                    style: TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          );
        }

        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: requests.length,
          separatorBuilder: (_, __) => const SizedBox(height: 12),
          itemBuilder: (context, index) {
            final req = requests[index];
            return _buildJoinRequestCard(req);
          },
        );
      },
    );
  }

  Widget _buildJoinRequestCard(JoinRequestModel req) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 18,
                backgroundColor: const Color(0xFFEFF6FF),
                child: Text(
                  req.studentName.isNotEmpty
                      ? req.studentName[0].toUpperCase()
                      : 'S',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF2563EB),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      req.studentName,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF0F172A),
                      ),
                    ),
                    Text(
                      req.studentEmail,
                      style: const TextStyle(
                        fontSize: 12,
                        color: Color(0xFF64748B),
                      ),
                    ),
                  ],
                ),
              ),
              if (req.requestedAt != null)
                Text(
                  DateFormat('dd MMM').format(req.requestedAt!),
                  style: const TextStyle(
                    fontSize: 11,
                    color: Color(0xFF64748B),
                  ),
                ),
            ],
          ),
          if (req.batchName.isNotEmpty ||
              (req.assignedBatchName != null &&
                  req.assignedBatchName!.isNotEmpty)) ...[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: const Color(0xFFF1F5F9),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                'Requested Batch: ${req.assignedBatchName ?? req.batchName}',
                style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF0F172A),
                ),
              ),
            ),
          ],
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              OutlinedButton(
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.red,
                  side: const BorderSide(color: Colors.red),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 6,
                  ),
                  textStyle: const TextStyle(fontSize: 12),
                ),
                onPressed: () => _confirmRejectRequest(req),
                child: const Text('Reject'),
              ),
              const SizedBox(width: 8),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 6,
                  ),
                  textStyle: const TextStyle(fontSize: 12),
                ),
                onPressed: () => _showApproveRequestDialog(req),
                child: const Text('Approve'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _showApproveRequestDialog(JoinRequestModel req) {
    final batches = widget.controller.batches;
    String? selectedBatchId =
        req.assignedBatchId ?? (req.batchId.isNotEmpty ? req.batchId : null);
    if (selectedBatchId == null && batches.isNotEmpty) {
      selectedBatchId = batches.first.id;
    }

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text('Approve Admission: ${req.studentName}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Approve ${req.studentName} (${req.studentEmail}) as an active student in ${widget.controller.orgName}.',
              ),
              const SizedBox(height: 14),
              const Text(
                'Assign Initial Batch (Optional):',
                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
              ),
              const SizedBox(height: 6),
              if (batches.isEmpty)
                const Text(
                  'No batches available. Student will join without batch.',
                  style: TextStyle(fontSize: 12, color: Colors.orange),
                )
              else
                DropdownButton<String>(
                  isExpanded: true,
                  value: selectedBatchId,
                  items: [
                    const DropdownMenuItem<String>(
                      value: null,
                      child: Text('No batch (General Admission)'),
                    ),
                    ...batches.map(
                      (b) => DropdownMenuItem<String>(
                        value: b.id,
                        child: Text(b.name),
                      ),
                    ),
                  ],
                  onChanged: (v) => setDialogState(() => selectedBatchId = v),
                ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
              ),
              onPressed: () async {
                Navigator.pop(context);
                final user = FirebaseAuth.instance.currentUser;
                final reviewerUid = user?.uid ?? '';
                final batchObj = batches
                    .where((b) => b.id == selectedBatchId)
                    .firstOrNull;

                try {
                  await _orgService.approveStudentJoinRequest(
                    orgId: widget.controller.orgId,
                    orgName: widget.controller.orgName,
                    requestId: req.id,
                    studentUid: req.studentUid,
                    studentName: req.studentName,
                    studentEmail: req.studentEmail,
                    studentPhone: req.studentPhone ?? '',
                    reviewerUid: reviewerUid,
                    assignedBatchId: selectedBatchId,
                    assignedBatchName: batchObj?.name,
                  );
                  CustomSnackbar.showSuccess(
                    context: context,
                    title: 'Student Approved',
                    message:
                        '${req.studentName} is now an active institute student.',
                  );
                } catch (e) {
                  CustomSnackbar.showError(
                    context: context,
                    title: 'Error',
                    message: 'Approval failed: $e',
                  );
                }
              },
              child: const Text(
                'Confirm Approval',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _confirmRejectRequest(JoinRequestModel req) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Reject Join Request?'),
        content: Text(
          'Are you sure you want to reject ${req.studentName}\'s request?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () async {
              Navigator.pop(context);
              final user = FirebaseAuth.instance.currentUser;
              final reviewerUid = user?.uid ?? '';
              try {
                await _orgService.rejectStudentJoinRequest(
                  orgId: widget.controller.orgId,
                  requestId: req.id,
                  reviewerUid: reviewerUid,
                );
                CustomSnackbar.showSuccess(
                  context: context,
                  title: 'Rejected',
                  message: 'Join request was rejected.',
                );
              } catch (e) {
                CustomSnackbar.showError(
                  context: context,
                  title: 'Error',
                  message: 'Action failed: $e',
                );
              }
            },
            child: const Text('Reject', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}

// =============================================================================
// TAB 4: OWNER BATCHES MANAGEMENT
// =============================================================================

class _OwnerBatchesTab extends StatefulWidget {
  final InstituteAdminDashboardController controller;
  final ActiveTenantContext tenantCtx;

  const _OwnerBatchesTab({required this.controller, required this.tenantCtx});

  @override
  State<_OwnerBatchesTab> createState() => _OwnerBatchesTabState();
}

class _OwnerBatchesTabState extends State<_OwnerBatchesTab> {
  final OrganizationService _orgService = OrganizationService();
  final TextEditingController _searchCtrl = TextEditingController();
  String _searchQuery = '';

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildBatchesHeader(),
        _buildSearchBar(),
        Expanded(
          child: StreamBuilder<List<BatchModel>>(
            stream: _orgService.streamInstituteBatches(widget.controller.orgId),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              final batches = snapshot.data ?? [];
              final filtered = batches.where((b) {
                if (_searchQuery.isEmpty) return true;
                final q = _searchQuery.toLowerCase();
                return b.name.toLowerCase().contains(q) ||
                    (b.subject != null && b.subject!.toLowerCase().contains(q));
              }).toList();

              if (filtered.isEmpty) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.class_outlined,
                          size: 48,
                          color: Colors.grey,
                        ),
                        const SizedBox(height: 10),
                        Text(
                          _searchQuery.isEmpty
                              ? 'No batches created yet.'
                              : 'No batches match "$_searchQuery".',
                          style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 12),
                        ElevatedButton.icon(
                          icon: const Icon(Icons.add, size: 16),
                          label: const Text('Create Batch'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primary,
                            foregroundColor: Colors.white,
                          ),
                          onPressed: _showCreateBatchSheet,
                        ),
                      ],
                    ),
                  ),
                );
              }

              return ListView.separated(
                padding: const EdgeInsets.all(16),
                itemCount: filtered.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, index) {
                  final b = filtered[index];
                  return _buildBatchCard(b);
                },
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildBatchesHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      color: Colors.white,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            'Institute Batches',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Color(0xFF0F172A),
            ),
          ),
          ElevatedButton.icon(
            icon: const Icon(Icons.add, size: 16),
            label: const Text('New Batch'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              textStyle: const TextStyle(fontSize: 12),
            ),
            onPressed: _showCreateBatchSheet,
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: TextField(
        controller: _searchCtrl,
        onChanged: (v) => setState(() => _searchQuery = v.trim()),
        decoration: InputDecoration(
          hintText: 'Search batches by name or subject...',
          prefixIcon: const Icon(Icons.search, size: 20),
          filled: true,
          fillColor: const Color(0xFFF1F5F9),
          contentPadding: const EdgeInsets.symmetric(vertical: 0),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }

  Widget _buildBatchCard(BatchModel b) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => Get.to(
          () => BatchDetailsScreen(orgId: widget.controller.orgId, batch: b),
        ),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          b.name,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF0F172A),
                          ),
                        ),
                        if (b.subject != null && b.subject!.isNotEmpty)
                          Text(
                            b.subject!,
                            style: const TextStyle(
                              fontSize: 12,
                              color: Color(0xFF64748B),
                            ),
                          ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: b.isArchived
                          ? Colors.grey.shade100
                          : const Color(0xFFDCFCE7),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      b.isArchived ? 'Archived' : 'Active',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: b.isArchived
                            ? Colors.grey.shade600
                            : const Color(0xFF166534),
                      ),
                    ),
                  ),
                ],
              ),
              if (b.schedule != null && b.schedule!.isNotEmpty) ...[
                const SizedBox(height: 6),
                Row(
                  children: [
                    const Icon(
                      Icons.schedule,
                      size: 13,
                      color: Color(0xFF64748B),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      b.schedule!,
                      style: const TextStyle(
                        fontSize: 12,
                        color: Color(0xFF64748B),
                      ),
                    ),
                  ],
                ),
              ],
              const SizedBox(height: 10),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF1F5F9),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      '${b.studentCount} Students',
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF0F172A),
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF1F5F9),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      '${b.assignedTeacherIds.length} Teachers',
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF0F172A),
                      ),
                    ),
                  ),
                  const Spacer(),
                  const Text(
                    'Details',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF2563EB),
                    ),
                  ),
                  const SizedBox(width: 2),
                  const Icon(
                    Icons.arrow_forward_ios,
                    size: 11,
                    color: Color(0xFF2563EB),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showCreateBatchSheet() {
    final nameCtrl = TextEditingController();
    final subjectCtrl = TextEditingController();
    final scheduleCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    final feeCtrl = TextEditingController();
    bool feeEnabled = true;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => StatefulBuilder(
        builder: (context, setSheetState) => Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            top: 20,
            left: 16,
            right: 16,
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Create Institute Batch',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF0F172A),
                  ),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: nameCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Batch Name *',
                    hintText: 'e.g. Class 12 Advanced Physics',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: subjectCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Subject',
                    hintText: 'e.g. Physics',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: scheduleCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Class Schedule',
                    hintText: 'e.g. Mon, Wed, Fri 4:00 PM - 5:30 PM',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: feeCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Monthly Fee (₹)',
                    hintText: '0 for free',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: descCtrl,
                  maxLines: 2,
                  decoration: const InputDecoration(
                    labelText: 'Description',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      foregroundColor: Colors.white,
                    ),
                    onPressed: () async {
                      final name = nameCtrl.text.trim();
                      if (name.isEmpty) return;
                      Navigator.pop(context);
                      final fee = double.tryParse(feeCtrl.text.trim()) ?? 0.0;
                      final user = FirebaseAuth.instance.currentUser;
                      final ownerUid = user?.uid ?? '';

                      try {
                        await _orgService.createInstituteBatch(
                          orgId: widget.controller.orgId,
                          name: name,
                          ownerUid: ownerUid,
                          subject: subjectCtrl.text.trim(),
                          schedule: scheduleCtrl.text.trim(),
                          description: descCtrl.text.trim(),
                          monthlyFee: fee,
                          feeTrackingEnabled: feeEnabled,
                        );
                        CustomSnackbar.showSuccess(
                          context: context,
                          title: 'Batch Created',
                          message: 'Batch "$name" has been created.',
                        );
                      } catch (e) {
                        CustomSnackbar.showError(
                          context: context,
                          title: 'Error',
                          message: 'Failed to create batch: $e',
                        );
                      }
                    },
                    child: const Text(
                      'Create Batch',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// =============================================================================
// TAB 5: OWNER MORE (SECONDARY MODULES & WORKSPACES)
// =============================================================================

class _OwnerMoreTab extends StatelessWidget {
  final InstituteAdminDashboardController controller;
  final ActiveTenantContext tenantCtx;

  const _OwnerMoreTab({required this.controller, required this.tenantCtx});

  @override
  Widget build(BuildContext context) {
    return ListView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
      children: [
        const Text(
          'Institute Features & Settings',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: Color(0xFF0F172A),
          ),
        ),
        const SizedBox(height: 14),
        _buildFeatureTile(
          title: 'Exam Management',
          subtitle: 'Create, schedule, and grade institute exams',
          icon: Icons.assignment_outlined,
          color: const Color(0xFF2563EB),
          onTap: () => Get.toNamed(AppRoutes.teacherExams),
        ),
        _buildFeatureTile(
          title: 'Attendance System',
          subtitle: 'Batch attendance overview, daily mark sheets and logs',
          icon: Icons.fact_check_outlined,
          color: const Color(0xFF0D9488),
          onTap: () => Get.toNamed(AppRoutes.attendanceOverview),
        ),
        _buildFeatureTile(
          title: 'Notices & Announcements',
          subtitle: 'Publish institute-wide or batch announcements',
          icon: Icons.campaign_outlined,
          color: const Color(0xFF7C3AED),
          onTap: () => Get.toNamed(AppRoutes.noticeList),
        ),
        _buildFeatureTile(
          title: 'Student Fee Management',
          subtitle:
              'Track monthly student fee dues, collections, and receipt ledger',
          icon: Icons.receipt_long_outlined,
          color: const Color(0xFFD97706),
          onTap: () => Get.toNamed(AppRoutes.ownerStudentFees),
        ),
        _buildFeatureTile(
          title: 'Teacher Salary Management',
          subtitle:
              'Configure base salaries and disburse monthly teacher compensation',
          icon: Icons.account_balance_wallet_outlined,
          color: const Color(0xFF059669),
          onTap: () => Get.toNamed(AppRoutes.ownerTeacherSalaries),
        ),
        _buildFeatureTile(
          title: 'Performance Analytics',
          subtitle: 'Student benchmarks, leaderboard, and score distributions',
          icon: Icons.insights_outlined,
          color: const Color(0xFF0284C7),
          onTap: () => Get.toNamed(AppRoutes.performanceAnalytics),
        ),
        _buildFeatureTile(
          title: 'Teacher Invitations',
          subtitle: 'Generate and manage expiring single-use invite codes',
          icon: Icons.mark_email_read_outlined,
          color: const Color(0xFF4F46E5),
          onTap: () => Get.toNamed(AppRoutes.manageInvitations),
        ),
        const Divider(height: 32),
        _buildFeatureTile(
          title: 'Switch Workspace',
          subtitle: 'Toggle between coaching institutes and private workspaces',
          icon: Icons.swap_horiz,
          color: const Color(0xFF475569),
          onTap: () => Get.toNamed(AppRoutes.organizationSwitcher),
        ),
        _buildFeatureTile(
          title: 'Sign Out',
          subtitle: 'Log out of your Owner account',
          icon: Icons.logout,
          color: Colors.red,
          onTap: () => _confirmSignOut(context),
        ),
      ],
    );
  }

  Widget _buildFeatureTile({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: color, size: 22),
        ),
        title: Text(
          title,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w700,
            color: Color(0xFF0F172A),
          ),
        ),
        subtitle: Text(
          subtitle,
          style: const TextStyle(fontSize: 12, color: Color(0xFF64748B)),
        ),
        trailing: const Icon(
          Icons.arrow_forward_ios,
          size: 14,
          color: Color(0xFF94A3B8),
        ),
        onTap: onTap,
      ),
    );
  }

  void _confirmSignOut(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sign Out?'),
        content: const Text(
          'Are you sure you want to sign out of your account?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () {
              Navigator.pop(context);
              Get.find<LoginController>().logout(context);
            },
            child: const Text(
              'Sign Out',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}
