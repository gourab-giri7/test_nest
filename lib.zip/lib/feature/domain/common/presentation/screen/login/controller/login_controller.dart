import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:test_nest/feature/auth/loginFeatureStudents/student_login_feature.dart';
import 'package:test_nest/feature/auth/loginFeatureTeacher/teacher_login_feature.dart';
import 'package:test_nest/feature/domain/common/presentation/widget/custom_Snackbar.dart';
import 'package:test_nest/feature/domain/student/presentation/screens/dashboard/students_dashboard_screen.dart';
import 'package:test_nest/feature/domain/teacher/data/models/teacher_data_model.dart';
import 'package:test_nest/feature/domain/teacher/presentation/screens/dashboard/teacher_dashboard_screen.dart';
import 'package:test_nest/main.dart';
import 'package:test_nest/feature/domain/student/data/models/student_data_model.dart';

class LoginController extends ChangeNotifier {
  TextEditingController teacherId = TextEditingController();
  TextEditingController id = TextEditingController();
  TextEditingController password = TextEditingController();
  bool isStudentLogin = false;
  bool obscurePassword = true;
  bool ispressed = false;

  // ------------- for main
  bool isLogined = false;
  String role = "";

  LoginController({bool initialIsLogined = false, String initialRole = ""})
      : isLogined = initialIsLogined,
        role = initialRole;

  void changeLoginToStudent() {
    isStudentLogin = true;
    id.clear();
    password.clear();
    notifyListeners();
  }

  void changeLoginState(bool isLogin, String rolee) {
    isLogined = isLogin;
    role = rolee;
    notifyListeners();
  }

  // ---------------- toggel show password
  void toggelLoginButton() {
    ispressed = !ispressed;
    notifyListeners();
  }

  // ---------------- toggel show password
  void toggeFields() {
    isStudentLogin = !isStudentLogin;
    notifyListeners();
  }

  // ---------------- toggel show password
  void toggelObscurePassword() {
    obscurePassword = !obscurePassword;
    notifyListeners();
  }

  // ----------- field validation
  String? fieldeValidation(String? value) {
    if (value == null || value.isEmpty) {
      return "Please fill the feild before login";
    } else {
      return null;
    }
  }

  // -------------- login function
  Future<void> login(BuildContext context) async {
    if (ispressed) return;
    ispressed = true;
    notifyListeners();

    try {
      final userId = id.text.trim();
      final userpassword = password.text.trim();

      if (!isStudentLogin) {
        // Teacher login
        final result = await TeacherLoginFeature.teacherlogin(
          userId,
          userpassword,
        );
        if (!context.mounted) return;

        if (result == 200) {
          loadTeacherData(userId, userpassword);
          isLogined = true;
          role = "teacher";
          ispressed = false;
          notifyListeners();
          customSnackbar(
            context: context,
            message: "Login successful",
            color: Colors.green,
            ico: Icons.login,
          );
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(
              builder: (context) => const TeacherDashboardScreen(),
            ),
            (route) => false,
          );
          return;
        } else if (result == 404) {
          customSnackbar(
            context: context,
            message: "Please enter valid ID and password",
            color: Colors.red,
            ico: Icons.error,
          );
        } else {
          customSnackbar(
            context: context,
            message: "Something went wrong, please try again later",
            color: Colors.orange,
            ico: Icons.info,
          );
        }
      } else {
        // Student login
        final teacherid = teacherId.text.trim();
        final result = await StudentLoginFeature.studentlogin(
          teacherid,
          userId,
          userpassword,
        );
        if (!context.mounted) return;

        if (result == 200) {
          loadStudentData(teacherid, userId, userpassword);
          isLogined = true;
          role = "student";
          ispressed = false;
          notifyListeners();
          customSnackbar(
            context: context,
            message: "Login successful",
            color: Colors.green,
            ico: Icons.login,
          );
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(
              builder: (context) => const StudentDashboardScreen(),
            ),
            (route) => false,
          );
          return;
        } else if (result == 404) {
          customSnackbar(
            context: context,
            message: "Please enter valid ID and password",
            color: Colors.red,
            ico: Icons.error,
          );
        } else {
          customSnackbar(
            context: context,
            message: "Something went wrong, please try again later",
            color: Colors.orange,
            ico: Icons.info,
          );
        }
      }
    } catch (e) {
      log("Login exception: $e");
      if (context.mounted) {
        customSnackbar(
          context: context,
          message: "Something went wrong, please try again later",
          color: Colors.red,
          ico: Icons.error,
        );
      }
    } finally {
      if (ispressed) {
        ispressed = false;
        notifyListeners();
      }
    }
  }

  // -------------- logout function
  Future<void> logout(BuildContext context) async {
    isLogined = false;
    role = "";
    teacherData = null;
    studentData = null;

    id.clear();
    password.clear();
    teacherId.clear();
    ispressed = false;

    await pref.clear();

    if (context.mounted) {
      Navigator.of(context).pushNamedAndRemoveUntil(
        '/login',
        (route) => false,
      );
    }

    notifyListeners();
  }
}

// ------------- load pref data (teacher)
void loadTeacherData(String userId, String userpassword) {
  pref.setString("id", userId);
  pref.setString("password", userpassword);
  pref.setString("role", "teacher");
  pref.setBool("isLogined", true);
}

// ------------- load pref data (student)
void loadStudentData(String teacherId, String userId, String userpassword) {
  pref.setString("teacherId", teacherId);
  pref.setString("id", userId);
  pref.setString("password", userpassword);
  pref.setString("role", "student");
  pref.setBool("isLogined", true);
}
