import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:test_nest/feature/domain/teacher/data/datasources/get_student_data.dart';
import 'package:test_nest/feature/domain/teacher/presentation/screens/CreateExam/controller/create_exam_controller.dart';
import 'package:test_nest/feature/domain/teacher/presentation/screens/manualQuestions/controller/question_controller.dart';

class CreateExamScreen extends StatefulWidget {
  const CreateExamScreen({super.key});
  @override
  State<CreateExamScreen> createState() => _CreateExamScreenState();
}

class _CreateExamScreenState extends State<CreateExamScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<CreateExamController>().clearAll();
    });
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<QuestionController>(
      create: (_) => QuestionController(),
      child: Builder(
        builder: (context) {
          final qc = context.watch<QuestionController>();
          return Consumer<CreateExamController>(
            builder: (context, c, _) {
              return Scaffold(
                backgroundColor: Colors.blueGrey[50],
                appBar: AppBar(
                  surfaceTintColor: Colors.transparent,
                  backgroundColor: Colors.blueGrey[50],
                  centerTitle: true,
                  title: const Text(
                    'Create Exam',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF0F172A),
                    ),
                  ),
                ),
                body: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 500),
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 10,
                      ),
                      child: Form(
                        key: c.examKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _label('Exam Name'),
                            _field(
                              controller: c.examNameController,
                              validator: c.nameValidator,
                              hint: 'e.g: Computer Hardware',
                            ),
                            const SizedBox(height: 16),
                            _label('Full Marks'),
                            _field(
                              controller: c.fullMarksController,
                              validator: c.marksValidator,
                              hint: 'e.g: 100',
                              keyboardType: TextInputType.number,
                            ),
                            const SizedBox(height: 16),
                            _label('Exam Date'),
                            _field(
                              controller: c.examDateController,
                              validator: c.nameValidator,
                              hint: 'Select Exam date',
                              readOnly: true,
                              suffix: const Icon(
                                Icons.calendar_today_outlined,
                                size: 20,
                                color: Colors.grey,
                              ),
                              onTap: () async {
                                final d = await showDatePicker(
                                  context: context,
                                  initialDate: DateTime.now(),
                                  firstDate: DateTime.now(),
                                  lastDate: DateTime(2200),
                                );
                                if (d != null) {
                                  c.pickedDate = d;
                                  c.selectExamDate();
                                }
                              },
                            ),
                            const SizedBox(height: 16),
                            Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      _label('Start Time'),
                                      _field(
                                        controller: c.startTimeController,
                                        validator: c.nameValidator,
                                        hint: 'Select Time',
                                        readOnly: true,
                                        suffix: const Icon(
                                          Icons.access_time,
                                          color: Colors.grey,
                                        ),
                                        onTap: () => _selectTime(
                                          c.startTimeController,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      _label('End Time'),
                                      _field(
                                        controller: c.endTimeController,
                                        validator: c.nameValidator,
                                        hint: 'Select Time',
                                        readOnly: true,
                                        suffix: const Icon(
                                          Icons.access_time,
                                          color: Colors.grey,
                                        ),
                                        onTap: () => _selectTime(
                                          c.endTimeController,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            _label('Exam Key'),
                            _field(
                              controller: c.examKeyController,
                              validator: c.nameValidator,
                              hint: 'e.g: CH@123',
                            ),
                            const SizedBox(height: 16),
                            _label('Instructions (Optional)'),
                            _field(
                              controller: c.instructionsController,
                              hint: 'e.g: 1st unit only',
                              maxLines: 2,
                            ),
                            const SizedBox(height: 22),

                            // Question Source Selector
                            _label('Question Source'),
                            _questionSourceSelector(c, qc),
                            const SizedBox(height: 22),

                            const Text(
                              'Assign Students',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF0F172A),
                              ),
                            ),
                            const SizedBox(height: 10),
                            _studentAssignment(c),
                            const SizedBox(height: 24),
                            SizedBox(
                              width: double.infinity,
                              height: 52,
                              child: ElevatedButton(
                                onPressed: c.selectedCount > 0
                                    ? () => c.next(context, qc)
                                    : null,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFF2563EB),
                                  elevation: 0,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                ),
                                child: Text(
                                  c.selectedCount == 0
                                      ? 'Select Students'
                                      : 'Next (${c.selectedCount} selected)',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Widget _questionSourceSelector(
    CreateExamController c,
    QuestionController qc,
  ) {
    return Row(
      children: [
        Expanded(
          child: _sourceCard(
            title: 'Excel Upload',
            subtitle: 'Upload .xlsx question sheet',
            icon: Icons.upload_file_outlined,
            isSelected: c.questionSource == QuestionSource.excel,
            onTap: () {
              c.setQuestionSource(QuestionSource.excel);
              qc.setSource(QuestionSource.excel);
            },
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _sourceCard(
            title: 'Manual Input',
            subtitle: 'Add questions one by one',
            icon: Icons.edit_note_outlined,
            isSelected: c.questionSource == QuestionSource.manual,
            onTap: () {
              c.setQuestionSource(QuestionSource.manual);
              qc.setSource(QuestionSource.manual);
            },
          ),
        ),
      ],
    );
  }

  Widget _sourceCard({
    required String title,
    required String subtitle,
    required IconData icon,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFFEFF6FF) : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected
                ? const Color(0xFF2563EB)
                : const Color(0xFFE2E8F0),
            width: isSelected ? 2 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.02),
              blurRadius: 6,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          children: [
            Icon(
              icon,
              size: 28,
              color: isSelected
                  ? const Color(0xFF2563EB)
                  : const Color(0xFF64748B),
            ),
            const SizedBox(height: 8),
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 14,
                color: isSelected
                    ? const Color(0xFF1E3A8A)
                    : const Color(0xFF0F172A),
              ),
            ),
            const SizedBox(height: 2),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 11,
                color: isSelected
                    ? const Color(0xFF3B82F6)
                    : const Color(0xFF64748B),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _studentAssignment(CreateExamController c) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: GetStudentData.getAllStudent(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting && !snap.hasData) {
          return const Padding(
            padding: EdgeInsets.all(20),
            child: Center(
              child: CircularProgressIndicator(color: Color(0xFF2563EB)),
            ),
          );
        }

        if (snap.hasError) {
          return const Text(
            'Unable to load students.',
            style: TextStyle(color: Colors.red),
          );
        }

        final docs = snap.data?.docs ?? [];
        c.setStudentsFromSnapshot(docs);

        final batches = c.classList;
        final hasBatches =
            batches.isNotEmpty && batches.first != 'select batch';

        if (!hasBatches) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: Text(
              'Please add batches/students before creating an exam',
              style: TextStyle(color: Colors.red, fontWeight: FontWeight.w500),
            ),
          );
        }

        final students = c.studentsForSelectedBatch;

        final dropdownValue = batches.contains(c.selectedbatch)
            ? c.selectedbatch
            : batches.first;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            DropdownButtonFormField<String>(
              value: dropdownValue,
              isExpanded: true,
              decoration: _dec(label: 'Batch'),
              items: batches
                  .map(
                    (b) => DropdownMenuItem(
                      value: b,
                      child: Text(b),
                    ),
                  )
                  .toList(),
              onChanged: (v) {
                if (v != null) c.setBatch(v);
              },
            ),
            const SizedBox(height: 12),
            if (students.isEmpty)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Center(
                  child: Text(
                    'No students found in this batch.',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: Colors.blueGrey,
                    ),
                  ),
                ),
              )
            else
              Card(
                elevation: 0,
                margin: EdgeInsets.zero,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                  side: const BorderSide(color: Color(0xFFE2E8F0)),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Checkbox(
                            value: c.allStudentsSelected,
                            onChanged: (v) => c.toggleAllStudents(v ?? false),
                          ),
                          const Expanded(
                            child: Text(
                              'Select all students',
                              style: TextStyle(fontWeight: FontWeight.w700),
                            ),
                          ),
                          Text(
                            '${c.selectedCount}/${students.length}',
                            style: const TextStyle(
                              color: Colors.blueGrey,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                      const Divider(height: 1, color: Color(0xFFE2E8F0)),
                      ...students.map(
                        (s) => CheckboxListTile(
                          dense: true,
                          contentPadding: EdgeInsets.zero,
                          value: c.selectedStudentIds.contains(s.id.trim()),
                          onChanged: (v) => c.toggleStudent(s.id, v ?? false),
                          title: Text(
                            s.name,
                            style: const TextStyle(fontWeight: FontWeight.w600),
                          ),
                          subtitle: Text(
                            'ID: ${s.id} • Batch: ${s.batch}',
                            style: const TextStyle(color: Colors.blueGrey),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        );
      },
    );
  }

  Widget _label(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Text(
          text,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w500,
            color: Colors.blueGrey,
          ),
        ),
      );

  Widget _field({
    required TextEditingController controller,
    String? Function(String?)? validator,
    String hint = '',
    bool readOnly = false,
    Widget? suffix,
    VoidCallback? onTap,
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
  }) =>
      TextFormField(
        controller: controller,
        validator: validator,
        readOnly: readOnly,
        onTap: onTap,
        keyboardType: keyboardType,
        maxLines: maxLines,
        onTapOutside: (_) => FocusManager.instance.primaryFocus?.unfocus(),
        decoration: _dec(hint: hint, suffix: suffix),
      );

  InputDecoration _dec({String? label, String hint = '', Widget? suffix}) =>
      InputDecoration(
        labelText: label,
        hintText: hint,
        suffixIcon: suffix,
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFE2E8F0)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFE2E8F0)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF2563EB)),
        ),
      );

  Future<void> _selectTime(TextEditingController controller) async {
    final t = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (t != null) controller.text = t.format(context);
  }
}
