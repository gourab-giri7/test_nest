import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:test_nest/feature/domain/student/presentation/screens/examHistory/controller/exam_controller.dart';
import 'package:test_nest/feature/domain/teacher/presentation/screens/allStudents/controller/student_controller.dart';
import 'package:test_nest/feature/domain/teacher/presentation/screens/fileUpload/controller/file_upload_controller.dart';
import 'package:test_nest/feature/domain/teacher/presentation/screens/reviewPublishExam/controller/publishExamController.dart';
import 'firebase_options.dart';
import 'package:test_nest/feature/domain/common/presentation/screen/login/controller/login_controller.dart';
import 'package:test_nest/feature/domain/common/presentation/screen/login/login_screen.dart';
import 'package:test_nest/feature/domain/teacher/presentation/screens/CreateExam/controller/create_exam_controller.dart';
import 'package:test_nest/feature/domain/teacher/presentation/screens/exams/controller/teacher_exam_controller.dart';
import 'package:test_nest/feature/domain/teacher/presentation/screens/addStudents/controller/add_student_controller.dart';
// import 'package:test_nest/feature/domain/teacher/presentation/screens/signup/controller/teacher_signup_controller.dart';

import 'dart:convert';
import 'dart:developer';

import 'package:test_nest/feature/domain/student/data/models/student_data_model.dart';
import 'package:test_nest/feature/auth/loginFeatureStudents/student_login_feature.dart';
import 'package:test_nest/feature/domain/teacher/data/models/teacher_data_model.dart';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import 'package:test_nest/feature/domain/common/presentation/screen/splash/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  // Suppress known FlutterFire platform stream de-activation race condition
  // during route changes / logout teardown.
  FlutterError.onError = (FlutterErrorDetails details) {
    final exception = details.exception;
    if (exception is MissingPluginException &&
        (details.context?.toString().contains(
                  'de-activating platform stream',
                ) ==
                true ||
            details.stack?.toString().contains(
                  'de-activating platform stream',
                ) ==
                true ||
            (exception.message?.contains('cancel') == true &&
                exception.message?.contains('firebase_firestore') == true))) {
      return;
    }
    FlutterError.presentError(details);
  };

  PlatformDispatcher.instance.onError = (error, stack) {
    if (error is MissingPluginException &&
        (error.message?.contains('cancel') == true &&
            error.message?.contains('firebase_firestore') == true)) {
      return true; // handled
    }
    return false;
  };

  pref = await SharedPreferences.getInstance();

  final isLogined = pref.getBool('isLogined') ?? false;
  final role = pref.getString('role') ?? "";
  bool validLoggedIn = false;

  if (isLogined && role == "teacher") {
    final teacherString = pref.getString("teacherData");
    if (teacherString != null && teacherString.trim().isNotEmpty) {
      try {
        teacherData = TeacherData.fromJson(jsonDecode(teacherString));
        validLoggedIn = true;
      } catch (e) {
        log("Failed to decode teacherData: $e");
        teacherData = null;
        await pref.clear();
      }
    } else {
      await pref.clear();
    }
  } else if (isLogined && role == "student") {
    final studentString = pref.getString("studentData");
    if (studentString != null && studentString.trim().isNotEmpty) {
      try {
        studentData = StudentData.fromJson(jsonDecode(studentString));
        final resolvedTeacherId =
            await StudentLoginFeature.resolveTeacherDocumentId(
              studentData!.teacherId,
            );
        if (resolvedTeacherId != null) {
          studentData!.teacherId = resolvedTeacherId;
          StudentData.updateStudentLocalData();
        }
        validLoggedIn = true;
      } catch (e) {
        log("Failed to decode studentData: $e");
        studentData = null;
        await pref.clear();
      }
    } else {
      await pref.clear();
    }
  }

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => LoginController(
            initialIsLogined: validLoggedIn,
            initialRole: validLoggedIn ? role : "",
          ),
        ),
        ChangeNotifierProvider(create: (context) => AddStudentController()),
        ChangeNotifierProvider(create: (context) => CreateExamController()),
        ChangeNotifierProvider(create: (context) => TeacherExamController()),
        ChangeNotifierProvider(create: (context) => StudentController()),
        ChangeNotifierProvider(create: (context) => ExamController()),
        ChangeNotifierProvider(create: (context) => FileUploadController()),
        ChangeNotifierProvider(create: (context) => Publishexamcontroller()),
      ],
      child: const MyApp(),
    ),
  );
}

late SharedPreferences pref;

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF2563EB),
      ),
      routes: {
        '/login': (context) => const LoginScreen(),
      },
      home: const SplashScreen(),
    );
  }
}
