// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flutter/material.dart';
// import 'package:test_nest/feature/domain/common/presentation/widget/custom_Snackbar.dart';
// class TeacherSignupController extends ChangeNotifier {
//   final formKey=GlobalKey<FormState>(); final name=TextEditingController(); final email=TextEditingController(); final password=TextEditingController(); final confirm=TextEditingController();
//   bool loading=false; bool obscure=true;
//   String? requiredField(String? v)=>v==null||v.trim().isEmpty?'Required':null;
//   void toggleObscure(){obscure=!obscure;notifyListeners();}
//   Future<void> signup(BuildContext context) async {if(!formKey.currentState!.validate()||loading)return;loading=true;notifyListeners();try{final clean=email.text.trim().toLowerCase();final ref=FirebaseFirestore.instance.collection('user').doc(clean);if((await ref.get()).exists){if(context.mounted)customSnackbar(context:context,message:'An account already exists for this email.',color:Colors.orange,ico:Icons.warning_amber_rounded);return;}final now=DateTime.now();final id='T${now.year.toString().substring(2)}${now.month.toString().padLeft(2,'0')}${now.microsecondsSinceEpoch.toString().substring(7)}';await ref.set({'id':id,'teacher_id':id,'name':name.text.trim(),'email':clean,'password':password.text,'last_std_id':'0','last_exam_id':'0','batch':<String>[],'role':'teacher','created_at':FieldValue.serverTimestamp()});if(context.mounted){customSnackbar(context:context,message:'Teacher account created. You can now log in.',color:Colors.green,ico:Icons.check_circle);Navigator.pop(context);}}catch(_){if(context.mounted)customSnackbar(context:context,message:'Registration failed. Please try again.',color:Colors.red,ico:Icons.error);}finally{loading=false;notifyListeners();}}
//   @override void dispose(){name.dispose();email.dispose();password.dispose();confirm.dispose();super.dispose();}
// }
