import 'dart:convert';

import 'package:test_nest/main.dart';

class TeacherData {
  String name;
  String password;
  String id;
  String teacherId;
  String lastStdId;
  String lastExamId;
  List<String> batch;
  TeacherData({
    required this.name,
    required this.password,
    required this.id,
    required this.teacherId,
    required this.lastStdId,
    required this.lastExamId,
    required this.batch,
  });
  factory TeacherData.fromJson(Map<String, dynamic> json, {String? docId}) {
    final String resolvedId = (docId != null && docId.trim().isNotEmpty)
        ? docId.trim()
        : (json["id"] ?? "").toString().trim();
    final String resolvedTeacherId =
        (json['teacher_id'] != null &&
            json['teacher_id'].toString().trim().isNotEmpty)
        ? json['teacher_id'].toString().trim()
        : (json['id'] ?? resolvedId).toString().trim();

    return TeacherData(
      id: resolvedId,
      name: (json['name'] ?? '').toString(),
      password: (json['password'] ?? '').toString(),
      teacherId: resolvedTeacherId,
      lastStdId: (json['last_std_id'] ?? '0').toString(),
      lastExamId: (json['last_exam_id'] ?? '0').toString(),
      batch: List<String>.from(json['batch'] ?? []),
    );
  }

  static Map<String, dynamic> toJson(TeacherData data) {
    return {
      "id": data.id,
      "name": data.name,
      "password": data.password,
      "teacher_id": data.teacherId,
      "last_std_id": data.lastStdId,
      "last_exam_id": data.lastExamId,
      "batch": data.batch,
    };
  }

  static Future<void> updateTeacherLocalData() async {
    if (teacherData != null) {
      String teacher = jsonEncode(TeacherData.toJson(teacherData!));
      await pref.setString("teacherData", teacher);
      await pref.setBool("isLogined", true);
      await pref.setString("role", "teacher");
      await pref.setString("id", teacherData!.id);
    }
  }
}

TeacherData? teacherData;
