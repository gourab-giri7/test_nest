class StudentModel {
  final String name;
  final String batch;
  final String id;
  final String password;
  final String? docId;

  StudentModel({
    required this.name,
    required this.batch,
    required this.id,
    required this.password,
    this.docId,
  });

  factory StudentModel.fromJson(Map<String, dynamic> json, {String? docId}) {
    final String resolvedId =
        (json['id'] != null && json['id'].toString().trim().isNotEmpty)
        ? json['id'].toString().trim()
        : (json['student_id'] != null &&
              json['student_id'].toString().trim().isNotEmpty)
        ? json['student_id'].toString().trim()
        : (docId != null && docId.trim().isNotEmpty)
        ? docId.trim()
        : '';

    return StudentModel(
      name: (json['name'] ?? '').toString().trim(),
      batch: (json['batch'] ?? '').toString().trim(),
      id: resolvedId,
      password: (json['password'] ?? '').toString(),
      docId: docId ?? (json['doc_id']?.toString() ?? resolvedId),
    );
  }

  StudentModel copyWith({
    String? name,
    String? batch,
    String? id,
    String? password,
    String? docId,
  }) {
    return StudentModel(
      name: name ?? this.name,
      batch: batch ?? this.batch,
      id: id ?? this.id,
      password: password ?? this.password,
      docId: docId ?? this.docId,
    );
  }

  static String normalizeBatch(String batch) {
    return batch
        .replaceAll('\uFEFF', '')
        .replaceAll('\u00A0', ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim()
        .toLowerCase();
  }

  static bool isSameBatch(String a, String b) {
    return normalizeBatch(a) == normalizeBatch(b);
  }

  static Map<String, dynamic> tojson(StudentModel data) {
    return {
      'name': data.name.trim(),
      'batch': data.batch.trim(),
      'id': data.id.trim(),
      'password': data.password,
    };
  }
}
