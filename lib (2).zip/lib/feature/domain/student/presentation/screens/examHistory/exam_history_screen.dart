import 'dart:async';
import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:test_nest/core/services/exam_firestore_service.dart';
import 'package:test_nest/core/utils/theme/theme.dart';
import 'package:test_nest/feature/domain/common/presentation/screen/login/login_screen.dart';
import 'package:test_nest/feature/domain/common/presentation/widget/custom_Snackbar.dart';
import 'package:test_nest/feature/domain/student/data/models/student_data_model.dart';
import 'package:test_nest/feature/domain/student/presentation/screens/examDetails/exam_details_screen.dart';
import 'package:test_nest/feature/domain/student/presentation/screens/examHistory/controller/exam_controller.dart';
import 'package:test_nest/feature/domain/student/presentation/screens/examResult/exam_result_review_screen.dart';
import 'package:test_nest/feature/domain/student/presentation/screens/takeExam/take_exam_screen.dart';
import 'package:test_nest/model/exam_model.dart';

class ExamHistoryScreen extends StatefulWidget {
  final StudentData? initialStudentData;
  final Stream<QuerySnapshot<Map<String, dynamic>>>? examStream;
  final int initialTab;

  const ExamHistoryScreen({
    super.key,
    this.initialStudentData,
    this.examStream,
    this.initialTab = 0,
  });

  @override
  State<ExamHistoryScreen> createState() => _ExamHistoryScreenState();
}

class _ExamHistoryScreenState extends State<ExamHistoryScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  final TextEditingController _searchController = TextEditingController();

  bool _isInitializing = true;
  StudentData? _currentStudent;
  Stream<QuerySnapshot<Map<String, dynamic>>>? _stream;
  String? _profileErrorMessage;
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: 4,
      vsync: this,
      initialIndex: widget.initialTab.clamp(0, 3),
    );
    _searchController.addListener(() {
      setState(() {
        _searchQuery = _searchController.text.trim().toLowerCase();
      });
    });
    _loadProfileAndStream();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadProfileAndStream({bool forceRefresh = false}) async {
    setState(() {
      _isInitializing = true;
      _profileErrorMessage = null;
    });

    try {
      StudentData? resolvedStudent = widget.initialStudentData ?? studentData;

      if (resolvedStudent == null || resolvedStudent.teacherId.trim().isEmpty) {
        resolvedStudent = await StudentData.restoreFromPreferences();
      }

      if (resolvedStudent == null ||
          resolvedStudent.id.trim().isEmpty ||
          resolvedStudent.teacherId.trim().isEmpty) {
        if (!mounted) return;
        setState(() {
          _currentStudent = null;
          _stream = null;
          _profileErrorMessage =
              'Student profile or enrolled teacher was not found. '
              'Please log in again to access your exam history.';
          _isInitializing = false;
        });
        return;
      }

      if (!mounted) return;

      final controller = Provider.of<ExamController?>(context, listen: false);
      if (forceRefresh && controller != null) {
        controller.refreshStream(teacherId: resolvedStudent.teacherId);
      }

      final rawStream = widget.examStream ??
          controller?.getExamStream(
            teacherId: resolvedStudent.teacherId,
            forceFresh: true,
          ) ??
          ExamFirestoreService.getStudentExamsStream(
            teacherId: resolvedStudent.teacherId,
          );

      // Add defensive timeout so the stream cannot hang in waiting state forever
      final streamInstance = rawStream.timeout(
        const Duration(seconds: 8),
        onTimeout: (sink) {
          log('Exam stream timed out in ExamHistoryScreen');
          sink.addError(
            TimeoutException(
              'Loading exams took longer than expected. Please check your internet connection or tap Refresh.',
            ),
          );
        },
      );

      setState(() {
        _currentStudent = resolvedStudent;
        _stream = streamInstance;
        _profileErrorMessage = null;
        _isInitializing = false;
      });
    } catch (e, stack) {
      log('Error initializing ExamHistoryScreen: $e', stackTrace: stack);
      if (!mounted) return;
      setState(() {
        _profileErrorMessage =
            'Failed to load student session. Please try logging in again.';
        _isInitializing = false;
      });
    }
  }

  void _onRetry() {
    _loadProfileAndStream(forceRefresh: true);
  }

  Stream<DocumentSnapshot<Map<String, dynamic>>>? _getSubmissionStream(
    String examId,
  ) {
    if (_currentStudent == null ||
        _currentStudent!.teacherId.isEmpty ||
        _currentStudent!.id.isEmpty) {
      return null;
    }
    try {
      return ExamFirestoreService.submission(
        _currentStudent!.teacherId,
        examId,
        _currentStudent!.id,
      ).snapshots();
    } catch (_) {
      return null;
    }
  }

  void _onStartExam(BuildContext context, ExamModel exam) {
    final studentId = _currentStudent?.id.trim() ?? '';
    final isAssigned = exam.isStudentAssigned(studentId);

    if (!isAssigned) {
      customSnackbar(
        context: context,
        message: 'You are not assigned to this exam.',
        color: Colors.red,
        ico: Icons.block,
      );
      return;
    }

    if (exam.status != 'Active' ||
        (exam.examEnd != null && DateTime.now().isAfter(exam.examEnd!))) {
      customSnackbar(
        context: context,
        message: 'This exam has ended and is no longer active.',
        color: Colors.red,
        ico: Icons.timer_off,
      );
      return;
    }

    if (exam.examKey.isEmpty) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => TakeExamScreen(exam: exam)),
      );
      return;
    }

    final keyController = TextEditingController();
    showDialog<void>(
      context: context,
      builder: (dialogCtx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text(
          'Enter Exam Key',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Enter the secure exam key to start ${exam.examName}:',
              style: TextStyle(fontSize: 13, color: Colors.grey[700]),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: keyController,
              autofocus: true,
              decoration: const InputDecoration(
                hintText: 'Exam Key',
                prefixIcon: Icon(Icons.key),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogCtx),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              if (keyController.text.trim() == exam.examKey.trim()) {
                Navigator.pop(dialogCtx);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => TakeExamScreen(exam: exam)),
                );
              } else {
                customSnackbar(
                  context: context,
                  message: 'Invalid Exam Key. Please check with your teacher.',
                  color: Colors.red,
                  ico: Icons.lock,
                );
              }
            },
            child: const Text('Start Now'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        surfaceTintColor: Colors.transparent,
        backgroundColor: AppColors.background,
        centerTitle: true,
        title: const Text(
          'Exam History',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: AppColors.text,
          ),
        ),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            icon: const Icon(Icons.refresh_rounded),
            onPressed: _onRetry,
          ),
        ],
      ),
      body: _buildBody(context),
    );
  }

  Widget _buildBody(BuildContext context) {
    if (_isInitializing) {
      return const Center(child: CircularProgressIndicator(color: Colors.blue));
    }

    if (_profileErrorMessage != null || _currentStudent == null) {
      return _buildProfileErrorState(
        _profileErrorMessage ??
            'Student profile is missing. Please log in again.',
      );
    }

    final activeStream = _stream;
    if (activeStream == null) {
      return _buildStreamErrorState(
        'Unable to establish connection to exam service.',
      );
    }

    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: activeStream,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          log('Exam stream error: ${snapshot.error}');
          return _buildStreamErrorState(
            'Failed to load exams. Please check your connection and try again.',
          );
        }

        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(color: Colors.blue),
          );
        }

        final docs = snapshot.data?.docs ?? [];
        final raw = <ExamModel>[];
        for (final doc in docs) {
          try {
            raw.add(ExamModel.fromJson(doc.data()));
          } catch (e) {
            log('Error parsing exam document ${doc.id}: $e');
          }
        }

        // Sort exams: newest start date first
        raw.sort((a, b) {
          final aStart = a.examStart;
          final bStart = b.examStart;
          if (aStart == null && bStart == null) {
            return b.examId.compareTo(a.examId);
          }
          if (aStart == null) return 1;
          if (bStart == null) return -1;
          return bStart.compareTo(aStart);
        });

        final studentId = _currentStudent!.id.trim();
        final studentBatch = _currentStudent!.batch.trim();
        final allAssigned = raw
            .where((exam) => exam.isStudentAssigned(
                  studentId,
                  studentBatch: studentBatch,
                ))
            .toList(growable: false);

        if (allAssigned.isEmpty) {
          return _buildEmptyAllExamsState();
        }

        // Apply search filter if active
        final filtered = _searchQuery.isEmpty
            ? allAssigned
            : allAssigned
                  .where((exam) {
                    final nameMatch = exam.examName.toLowerCase().contains(
                      _searchQuery,
                    );
                    final batchMatch = exam.batch.toLowerCase().contains(
                      _searchQuery,
                    );
                    return nameMatch || batchMatch;
                  })
                  .toList(growable: false);

        final active = filtered
            .where((e) => e.status == 'Active')
            .toList(growable: false);
        final upcoming = filtered
            .where((e) => e.status == 'Upcoming')
            .toList(growable: false);
        final completed = filtered
            .where((e) => e.status == 'Completed')
            .toList(growable: false);

        return RefreshIndicator(
          onRefresh: () async => _onRetry(),
          color: Colors.blue,
          child: Column(
            children: [
              // Summary stats overview card
              _buildStatsBanner(
                total: allAssigned.length,
                active: allAssigned.where((e) => e.status == 'Active').length,
                upcoming: allAssigned
                    .where((e) => e.status == 'Upcoming')
                    .length,
                completed: allAssigned
                    .where((e) => e.status == 'Completed')
                    .length,
              ),

              // Search field
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 6,
                ),
                child: TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Search exams by title or batch...',
                    prefixIcon: const Icon(Icons.search, size: 20),
                    suffixIcon: _searchQuery.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear, size: 18),
                            onPressed: () => _searchController.clear(),
                          )
                        : null,
                    isDense: true,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 10,
                    ),
                    fillColor: Colors.white,
                    filled: true,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: Color(0xFFE2E8F0)),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: Color(0xFFE2E8F0)),
                    ),
                  ),
                ),
              ),

              // Tabs
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 4,
                ),
                child: TabBar(
                  controller: _tabController,
                  isScrollable: true,
                  indicatorColor: Colors.blue,
                  tabAlignment: TabAlignment.center,
                  labelPadding: const EdgeInsets.symmetric(horizontal: 12),
                  tabs: const [
                    Tab(text: 'All'),
                    Tab(text: 'Active'),
                    Tab(text: 'Upcoming'),
                    Tab(text: 'Completed'),
                  ],
                ),
              ),

              // TabBar content
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    _buildExamList(filtered, 'All'),
                    _buildExamList(active, 'Active'),
                    _buildExamList(upcoming, 'Upcoming'),
                    _buildExamList(completed, 'Completed'),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildStatsBanner({
    required int total,
    required int active,
    required int upcoming,
    required int completed,
  }) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 6),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFE2E8F0)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.02),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _statItem('Assigned', '$total', Icons.assignment, Colors.blue),
            _statDivider(),
            _statItem('Active', '$active', Icons.bolt, Colors.teal),
            _statDivider(),
            _statItem('Upcoming', '$upcoming', Icons.schedule, Colors.orange),
            _statDivider(),
            _statItem(
              'Completed',
              '$completed',
              Icons.check_circle_outline,
              Colors.green,
            ),
          ],
        ),
      ),
    );
  }

  Widget _statDivider() {
    return Container(width: 1, height: 28, color: const Color(0xFFE2E8F0));
  }

  Widget _statItem(String label, String value, IconData icon, Color color) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 14, color: color),
            const SizedBox(width: 4),
            Text(
              value,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ],
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: const TextStyle(
            fontSize: 11,
            color: AppColors.textSecondary,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  Widget _buildExamList(List<ExamModel> exams, String label) {
    if (exams.isEmpty) {
      final isSearching = _searchQuery.isNotEmpty;
      return Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                isSearching ? Icons.search_off : Icons.assignment_outlined,
                size: 54,
                color: Colors.blueGrey[300],
              ),
              const SizedBox(height: 12),
              Text(
                isSearching
                    ? 'No exams match "$_searchQuery"'
                    : 'No $label exam available',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.blueGrey,
                ),
              ),
              if (isSearching) ...[
                const SizedBox(height: 8),
                TextButton(
                  onPressed: () => _searchController.clear(),
                  child: const Text('Clear Search Filter'),
                ),
              ],
            ],
          ),
        ),
      );
    }

    return ListView.separated(
      physics: const AlwaysScrollableScrollPhysics(
        parent: BouncingScrollPhysics(),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      itemCount: exams.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        final exam = exams[index];
        return _buildLiveExamCard(exam, context);
      },
    );
  }

  Widget _buildLiveExamCard(ExamModel exam, BuildContext context) {
    final submissionStream = _getSubmissionStream(exam.examId);

    if (submissionStream == null) {
      return _buildStaticCard(exam, context, submission: null);
    }

    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: submissionStream,
      builder: (context, snap) {
        final subData = snap.data?.data();
        final isSubmitted = snap.data?.exists ?? false;

        return _buildStaticCard(
          exam,
          context,
          submission: isSubmitted ? subData : null,
        );
      },
    );
  }

  Widget _buildStaticCard(
    ExamModel exam,
    BuildContext context, {
    required Map<String, dynamic>? submission,
  }) {
    final bool isSubmitted = submission != null;
    final bool isActive = exam.status == 'Active';
    final bool isUpcoming = exam.status == 'Upcoming';

    final scoreStr = submission?['score']?.toString();
    final attemptedCount = submission?['attempted']?.toString();

    // Determine status badge
    Color badgeColor;
    Color badgeBg;
    String badgeText;
    IconData badgeIcon;

    if (isSubmitted) {
      if (exam.resultPublished && scoreStr != null) {
        badgeColor = Colors.green[800]!;
        badgeBg = Colors.green.withOpacity(0.12);
        badgeText = 'Score: $scoreStr / ${exam.fullMarks}';
        badgeIcon = Icons.check_circle;
      } else {
        badgeColor = Colors.orange[800]!;
        badgeBg = Colors.orange.withOpacity(0.12);
        badgeText = 'Submitted • Pending Result';
        badgeIcon = Icons.hourglass_top_rounded;
      }
    } else if (isActive) {
      badgeColor = Colors.blue[800]!;
      badgeBg = Colors.blue.withOpacity(0.12);
      badgeText = 'Active Now';
      badgeIcon = Icons.bolt;
    } else if (isUpcoming) {
      badgeColor = Colors.purple[800]!;
      badgeBg = Colors.purple.withOpacity(0.12);
      badgeText = 'Upcoming';
      badgeIcon = Icons.schedule;
    } else {
      badgeColor = Colors.blueGrey;
      badgeBg = Colors.blueGrey.withOpacity(0.10);
      badgeText = 'Ended';
      badgeIcon = Icons.timer_off_outlined;
    }

    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ExamDetailsScreen(exam: exam),
          ),
        );
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: isActive && !isSubmitted
                ? Colors.blue.withOpacity(0.5)
                : const Color(0xFFF1F5F9),
            width: isActive && !isSubmitted ? 1.5 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.02),
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top Row: Title + Status Badge
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Text(
                    exam.examName,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: AppColors.text,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: badgeBg,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(badgeIcon, size: 13, color: badgeColor),
                      const SizedBox(width: 4),
                      Text(
                        badgeText,
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: badgeColor,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),

            // Middle: Metadata Chips (Date, Time, Marks, Questions, Batch)
            Wrap(
              spacing: 12,
              runSpacing: 6,
              children: [
                _metaChip(Icons.calendar_today, exam.examDate),
                _metaChip(
                  Icons.access_time,
                  '${exam.startTime} - ${exam.endTime}',
                ),
                _metaChip(Icons.star_outline, '${exam.fullMarks} Marks'),
                _metaChip(
                  Icons.help_outline,
                  '${exam.questionCount} Questions',
                ),
                _metaChip(
                  Icons.class_outlined,
                  exam.batch.isEmpty ? 'All Batches' : exam.batch,
                ),
              ],
            ),

            // Submission / Result Banner (if submitted)
            if (isSubmitted) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: exam.resultPublished
                      ? Colors.green.withOpacity(0.06)
                      : Colors.orange.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: exam.resultPublished
                        ? Colors.green.withOpacity(0.25)
                        : Colors.orange.withOpacity(0.25),
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      exam.resultPublished
                          ? Icons.fact_check_outlined
                          : Icons.hourglass_empty_rounded,
                      size: 20,
                      color: exam.resultPublished
                          ? Colors.green[700]
                          : Colors.orange[700],
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            exam.resultPublished
                                ? 'Final Score: $scoreStr / ${exam.fullMarks}'
                                : 'Attempt recorded. Results pending.',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              color: exam.resultPublished
                                  ? Colors.green[800]
                                  : Colors.orange[800],
                            ),
                          ),
                          if (attemptedCount != null)
                            Text(
                              'Attempted $attemptedCount of ${exam.questionCount} questions',
                              style: TextStyle(
                                fontSize: 11,
                                color: Colors.grey[600],
                              ),
                            ),
                        ],
                      ),
                    ),
                    if (exam.resultPublished)
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green[700],
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 6,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          elevation: 0,
                        ),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => ExamResultReviewScreen(
                                exam: exam,
                                submission: submission,
                              ),
                            ),
                          );
                        },
                        icon: const Icon(Icons.analytics_outlined, size: 14),
                        label: const Text(
                          'Review Answers',
                          style: TextStyle(fontSize: 12),
                        ),
                      ),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 12),

            // Bottom Actions: Start Exam (if active & not submitted), or View Details
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Exam ID: ${exam.examId}',
                  style: TextStyle(
                    fontSize: 11,
                    color: Colors.grey[500],
                    fontWeight: FontWeight.w500,
                  ),
                ),
                if (isActive && !isSubmitted)
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 1,
                    ),
                    onPressed: () => _onStartExam(context, exam),
                    icon: const Icon(Icons.play_arrow_rounded, size: 18),
                    label: const Text(
                      'Start Exam',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                      ),
                    ),
                  )
                else
                  TextButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ExamDetailsScreen(exam: exam),
                        ),
                      );
                    },
                    icon: const Icon(Icons.arrow_forward_rounded, size: 15),
                    label: const Text(
                      'View Details',
                      style: TextStyle(fontSize: 12),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _metaChip(IconData icon, String text) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 13, color: Colors.grey[500]),
        const SizedBox(width: 4),
        Text(
          text,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey[600],
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  Widget _buildProfileErrorState(String message) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.amber.withOpacity(0.12),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.account_circle_outlined,
                size: 56,
                color: Colors.amber,
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'Profile Not Found',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: AppColors.text,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
                height: 1.4,
              ),
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                OutlinedButton.icon(
                  onPressed: _onRetry,
                  icon: const Icon(Icons.refresh, size: 18),
                  label: const Text('Retry'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.blue,
                    side: const BorderSide(color: Colors.blue),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 10,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const LoginScreen(),
                      ),
                      (route) => false,
                    );
                  },
                  icon: const Icon(Icons.login, size: 18),
                  label: const Text('Log In Again'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 10,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStreamErrorState(String message) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.red.withOpacity(0.08),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.cloud_off_rounded,
                size: 56,
                color: Colors.redAccent,
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'Failed to Load Exams',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: AppColors.text,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
                height: 1.4,
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _onRetry,
              icon: const Icon(Icons.refresh, size: 18),
              label: const Text('Retry'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 10,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyAllExamsState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blue.withOpacity(0.08),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.assignment_outlined,
                size: 56,
                color: Colors.blue,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'No Exam found',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: AppColors.text,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'You have not been assigned to any exams yet.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, color: Colors.grey[600]),
            ),
          ],
        ),
      ),
    );
  }
}
